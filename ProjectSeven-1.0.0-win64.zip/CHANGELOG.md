# Changelog - Project Seven

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial implementation of physically modelled seven-string electric guitar VST3
- Extended Karplus-Strong / digital waveguide string synthesis
- Magnetic pickup sensing with position and harmonic cancellation
- Seven independent string configurations
- Tuning presets: Standard B, Drop A, Drop G, Drop F
- Custom tuning save/load (.ps7t XML format)
- MIDI support: note on/off, velocity, pitch bend, sustain, all-notes-off
- Keyswitches: C0 (Open), C#0 (Palm), D0 (Nat. Harm), D#0 (Pinch)
- CC20 articulation control, CC64 sustain
- Natural and pinch/artificial harmonics
- Palm muting with physical damping
- Clean DI output only (no built-in effects)
- Custom dark industrial editor GUI
- Editor snapshot tool for visual verification
- VST3 host smoke test
- Comprehensive engine test suite (111 checks)
- WAV artifacts for manual listening

### Fixed
- Static MSVC runtime linking (no VCRUNTIME140/MSVCP140/UCRT dependencies)
- Zero audio-thread allocations during note-on/render
- Oversized host block processing with preallocated buffer
- Retrigger same note/string click prevention (6ms fade)
- Clicks/glitches stability at common sample rates and block sizes

### Known Issues
- Cubase 15 / clean-machine validation not performed (only JUCE host smoke test)
- Manual listening not performed (WAV artifacts available)
- Some edge cases may not be fully covered

## [1.0.0] - 2026-10-31

### Added
- Initial public release
- All features as listed above
