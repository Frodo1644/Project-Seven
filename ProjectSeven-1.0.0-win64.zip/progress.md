# Project Seven - Progress Tracking Log

Track of implementation for the physically modelled seven-string electric guitar VST3 instrument.

## Environment (Stage 0)
- [x] Windows environment installed and verified
- [x] MSVC 14.44.35207, Windows SDK 10.0.26100.0, CMake 4.4.4, VS 17 2022 generator
- [x] JUCE 9.0.4 at `C:/SDK/JUCE/install`
- [x] Cubase 15 / clean Windows machine validation not performed (design limitation)
- [x] Documentation on environment setup complete

## Architecture Decisions (Stage 0)
- [x] VST3 instrument only; no VST2, standalone, AU, AAX
- [x] Physical modelling via extended Karplus-Strong / digital waveguide
- [x] Fractional delay, two one-pole loop lowpasses, 4 allpass dispersion, triangular excitation
- [x] Two-tap pickup comb, pitch-dependent T60, palm-mute damping, flageolet excitation
- [x] Shared pickup electrical: 28 Hz HP, ~4300 Hz resonance, ~9500 Hz rolloff, DC blocker
- [x] MIDI keyswifts C0/C#0/D0/D#0, CC20, CC64, CC120/121/123
- [x] Presets Standard B, Drop A, Drop G, Drop F; custom tunings savable/restorable
- [x] Static MSVC runtime via ` CMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded`
- [x] Core engine / processor / editor in static lib `projectseven_core`; plugin target compiles only PluginEntry
- [x] Tests use same core as plugin

## Implementation (Stage 1-2)
- [x] Parameters, tuning manager, preset manager
- [x] String model, pickup model
- [x] Seven-string engine, processor, entry point
- [x] Full dark industrial editor with custom look-and-feel
- [x] String display names conventional guitar numbering; parameter IDs string1-string7
- [x] Atomic status fields and momentary articulation for UI reads
- [x] Retrigger fade (6ms) for same note/string click prevention
- [x] Chunked oversized-block rendering with preallocated monoBuffer

## Tests (Stage 3)
- [x] 111 checks, 0 failures at 48 kHz
- [x] CPU 10s / 7 voices in ~0.074s (0.74% real time)
- [x] Zero allocations during note-on/render
- [x] Sample rates 44.1/48/88.2/96/192 kHz tested
- [x] Block sizes 64-1024 tested
- [x] Oversized block / no-allocation test added
- [x] Frequency accuracy, excitation, decay, damping, harmonics, tuning, MIDI, velocity, pitch bend, polyphony/stealing, parameter persistence, audio stability tests
- [x] WAV artifacts for manual listening in `artifacts/`

## VST3 Bundle (Stage 3)
- [x] VST3 built: `build/ProjectSeven_artefacts/Release/VST3/Project Seven.vst3` (8.3 MB DLL)
- [x] VST3 host smoke test passes: bundle discovered, instrument, stereo out/no inputs, MIDI plays audio (peak 0.1959), 2s finite, state save/load, hosted editor created at 1000x650
- [x] `dumpbin /dependents` shows no VCRUNTIME140/MSVCP140/UCRT dependencies (static runtime confirmed)
- [x] Only Windows system DLLs remain

## Editor Visuals (Stage 4)
- [x] `editor_preview.png` (1000x650) - visual verification
- [x] `editor_small.png` (900x585, Drop F preset, note E2) - visual verification
- [x] Footer status works
- [x] Dark industrial palette: #101113 bg, #202328 panels, #343840 borders, #E5E7EA text, #9298A2 secondary, #B52132 accent, #E03B4B highlight, #C58B4A optional

## Stage 5: Release/Distribution
- [ ] README.md - IN PROGRESS
- [ ] BUILD.md - NOT STARTED
- [ ] ARCHITECTURE.md - IN PROGRESS
- [ ] TESTING.md - NOT STARTED
- [ ] CHANGELOG.md - NOT STARTED
- [ ] Distribution ZIP with VST3 bundle, docs, install instructions, source - NOT STARTED
- [ ] Final verification: ctest with smoke target built - NOT STARTED

## Interim Actions Taken
- [x] Added TUNE_STIFFNESS to StringParams for micro-tuned strings waveform clearing
- [x] CXX_STANDARD 20 removed from juce_add_plugin (was polluting moduleinfo.json subcategories)
- [x] Ticks in string column now visible with kTextDim/white colours
- [x] Text-based strings added TUNE_STIFFNESS accumulation when notes overlap
- [x] StringColumn::setString now invalidates/scrolls on active voices/fret
- [x] setInnerSize new strategy replaces height then calls setSize for correct layout
- [x] Selected string now scrolls into view when changed
- [x] statusTimerPeriod default 300ms for faster endpoint status
- [x] Editor constructor simplified: no call to construct with no args

## Open Issues
- [ ] Cubase 15 / clean-machine validation not performed; only JUCE host smoke test + dependency inspection
- [ ] Manual listening not performed (WAV artifacts available)
- [ ] TESTING.md and BUILD.md not yet written
- [ ] distribution ZIP not yet created
- [ ] Final ctest verification not yet performed
