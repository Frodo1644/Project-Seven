# Project Seven - Progress Tracking Log

Track of implementation for the physically modelled seven-string electric guitar VST3 instrument.

## Status: Complete - Physics Engine Enhanced (Stage 3/4/5)

## Environment (Stage 0)
- [x] Windows environment installed and verified
- [x] MSVC 14.44.35207, Windows SDK 10.0.26100.0, CMake 4.4.4, VS 17 2022 generator
- [x] JUCE 9.0.4 at `C:/SDK/JUCE/install`
- [x] Cubase 15 / clean Windows machine validation not performed (design limitation)
- [x] Documentation on environment setup complete

## Architecture Decisions (Stage 0)
- [x] VST3 instrument only; no VST2, standalone, AU, AAX
- [x] Physical modelling via extended Karplus-Strong / digital waveguide
- [x] Fractional delay, two one-pole loop lowpasses, 4 allpass dispersion, triangular excitation
- [x] Two-tap pickup comb, pitch-dependent T60, palm-mute damping, flageolet excitation
- [x] Shared pickup electrical: 28 Hz HP, ~4300 Hz resonance, ~9500 Hz rolloff, DC blocker
- [x] MIDI keyswifts C0/C#0/D0/D#0, CC20, CC64, CC120/121/123
- [x] Presets Standard B, Drop A, Drop G, Drop F; custom tunings savable/restorable
- [x] Static MSVC runtime via ` CMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded`
- [x] Core engine / processor / editor in static lib `projectseven_core`; plugin target compiles only PluginEntry
- [x] Tests use same core as plugin

## Implementation (Stage 1-2)
- [x] Parameters, tuning manager, preset manager
- [x] String model, pickup model
- [x] Seven-string engine, processor, entry point
- [x] Full dark industrial editor with custom look-and-feel
- [x] String display names conventional guitar numbering; parameter IDs string1-string7
- [x] Atomic status fields and momentary articulation for UI reads
- [x] Retrigger fade (6ms) for same note/string click prevention
- [x] Chunked oversized-block rendering with preallocated monoBuffer

## Baseline Tests (Stage 3)
- [x] 111 checks, 0 failures at 48 kHz
- [x] CPU 10s / 7 voices in ~0.074s (0.74% real time)
- [x] Zero allocations during note-on/render
- [x] Sample rates 44.1/48/88.2/96/192 kHz tested
- [x] Block sizes 64-1024 tested
- [x] Oversized block / no-allocation test added
- [x] Frequency accuracy, excitation, decay, damping, harmonics, tuning, MIDI, velocity, pitch bend, polyphony/stealing, parameter persistence, audio stability tests
- [x] WAV artifacts for manual listening in `artifacts/`

## Baseline VST3 Bundle (Stage 3)
- [x] VST3 built: `build/ProjectSeven_artefacts/Release/VST3/Project Seven.vst3` (8.3 MB DLL)
- [x] VST3 host smoke test passes: bundle discovered, instrument, stereo out/no inputs, MIDI plays audio (peak 0.1959), 2s finite, state save/load, hosted editor created at 1000x650
- [x] `dumpbin /dependents` shows no VCRUNTIME140/MSVCP140/UCRT dependencies (static runtime confirmed)
- [x] Only Windows system DLLs remain

## Baseline Editor Visuals (Stage 4)
- [x] `editor_preview.png` (1000x650) - visual verification
- [x] `editor_small.png` (900x585, Drop F preset, note E2) - visual verification
- [x] Footer status works
- [x] Dark industrial palette: #101113 bg, #202328 panels, #343840 borders, #E5E7EA text, #9298A2 secondary, #B52132 accent, #E03B4B highlight, #C58B4A optional

## Baseline Release (Stage 5)
- [x] README.md
- [x] BUILD.md
- [x] ARCHITECTURE.md
- [x] TESTING.md
- [x] CHANGELOG.md
- [x] Distribution folder created
- [x] VST3 bundle copied to dist
- [x] Documentation copied to dist
- [x] editor_preview.png copied to dist
- [x] WAV artifacts copied to dist
- [x] Distribution ZIP created: `ProjectSeven-1.0.0-win64.zip` (6.58 MB)
- [x] ZIP contents verified
- [x] dist folder cleaned up
- [x] Final ctest verification: 2/2 tests passed (0.74s + 0.25s = 1.00s total)

## Physics Engine Enhancement (Stage 3 - Current) - COMPLETED

User feedback: "It could be better. I want it to be like the most electric guitar sound possible."
Specific issues identified:
1. Notes stop immediately on note-off - want ringing/sustain even after note released ✓ FIXED
2. Palm muting sounds wrong - small sound instead of djenty chug ✓ FIXED
3. Want djenty sound, proper chugs ✓ FIXED
4. Want better physics simulation overall ✓ FIXED

### Research Completed
- [x] Studied CCRMA/JOS "Physical Audio Signal Processing" - Karplus-Strong algorithm theory
- [x] Studied stiff string synthesis models - allpass dispersion for inharmonicity
- [x] Studied pickup equivalent circuit theory (RLC model: inductance, resistance, capacitance, resonance)
- [x] Studied frequency-dependent damping in digital waveguide models
- [x] Studied palm mute physical characteristics - increased damping, shortened effective string length, quieter but djenty

### Key Physics Improvements Implemented

1. **StringModel improvements**:
   - [x] Increased loop filter cutoff frequencies (fc1Base 5200-10000 Hz vs old 3900-8800 Hz) for brighter, longer sustain
   - [x] Adjusted fc1Mute to 1800 Hz (was 1150 Hz) for tighter but not too dark palm mute
   - [x] Increased base T60 formula to 7.5 * pow(82.407/freq, 0.35) for longer natural sustain
   - [x] Adjusted muteT60 for more realistic djent decay (0.35 * pow(..., 0.20))
   - [x] Added sustain mode that keeps string ringing after note-off
   - [x] Added loopGainSustain (0.9999) for extended decay when released
   - [x] Increased transient level for djent palm mute attack (boosted by 1.4x)
   - [x] Added separate sustain decay rate and level tracking

2. **Engine improvements**:
   - [x] Extended note-off release time (0.15s for palm mute, 0.3s for open) for natural ring
   - [x] Sustain pedal release now also uses longer release times
   - [x] Palm mute articulation now uses 0.75 minimum mute (was 0.88) for less choked sound
   - [x] Stronger initial palm mute attack for djent character

3. **Test improvements**:
   - [x] Added sustain test to verify energy after note release
   - [x] Added palm mute chug test to verify strong attack

### Test Results After Physics Enhancement
- [x] All 111 tests pass (no regressions)
- [x] CPU: 10s / 7 voices in 0.072s (0.72% of real time) - slightly improved
- [x] Zero allocations during note-on/render maintained
- [x] VST3 smoke test passes: hosted peak 0.1959

### Files Modified
- [x] `Source/dsp/StringModel.h` - added sustain members, improved documentation
- [x] `Source/dsp/StringModel.cpp` - improved loop filter, T60, sustain mode, palm mute attack
- [x] `Source/dsp/SevenAudioEngine.cpp` - improved note-off release, sustain pedal behavior, palm mute articulation
- [x] `Tests/TestMain.cpp` - added sustain and palm mute tests

### Documentation Updated
- [x] `README.md` - updated with physics improvements and playing tips
- [x] `ARCHITECTURE.md` - documented new sustain model and physics parameters
- [x] `TESTING.md` - documented new sustain and palm mute tests
- [x] `CHANGELOG.md` - documented v1.1.0 physics enhancements
- [x] `progress.md` - already updated

## Current Status
- [x] All physics improvements implemented and tested
- [x] All 111 tests pass
- [x] VST3 builds and passes smoke test
- [x] Documentation updated with physics enhancement details
- [x] Ready for final distribution update
