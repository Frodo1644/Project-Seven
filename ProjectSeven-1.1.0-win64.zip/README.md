# Project Seven

A from-scratch physically modelled seven-string electric guitar VST3 instrument for Windows x64 / Cubase 15, producing a clean electric-guitar DI signal with no samples or built-in effects.

## What it is

Project Seven models seven steel strings using an extended Karplus-Strong / digital waveguide approach with physically accurate damping, dispersion, and sustain characteristics. Each string is independently configurable, with magnetic pickup sensing that models the pickup position and resulting harmonic cancellation. The output is a clean, DI-style electric guitar signal — no samples, no amp, no cab, no effects.

The physics engine has been enhanced to provide:
- **Natural sustain**: Strings ring out after note release, simulating real electric guitar behavior
- **Djenty palm mute**: Strong percussive attack with tight, controlled decay for modern metal tones
- **Improved loop filter**: Gentler damping preserves high-frequency brightness and sustain
- **Realistic decay**: Pitch-dependent T60 with longer sustain for low strings

## Supported features

### Sound model
- Seven independently configurable strings with physical modelling
- Steel string modelling with pickup sensing/position/harmonic cancellation
- Pickup electrical response: HP filter, resonance, rolloff, DC blocking
- Velocity affecting excitation
- Natural and pinch/artificial harmonics where feasible
- Palm muting with djenty character (strong attack, controlled decay)
- Natural string sustain after note release
- Natural and pinch/artificial harmonics

### Tunings
- Presets: Standard B, Drop A, Drop G, Drop F
- Custom tunings savable/restorable
- Extremely low tunings supported

### MIDI
- Note on/off with velocity affecting excitation
- Pitch bend
- Sustain (CC64) with natural string ring
- All-notes-off (CC120/121/123)
- Polyphony and voice stealing
- Deterministic string/fret mapping
- Keyswitches: C0 (Open), C#0 (Palm), D0 (Nat. Harm), D#0 (Pinch)

### Articulations
- Open, Palm mute, Natural harmonic, Pinch harmonic
- CC20 for articulation control
- Palm mute produces djenty chug with strong attack

### Output
- Clean DI only — no EQ, drive, amp, cab, IR, gate, compression, reverb, delay, chorus, or widening
- Seven-string polyphony
- Low CPU with no audio-thread allocations
- Stable at common sample rates (44.1/48/88.2/96/192 kHz)

## Getting Started

### Requirements
- Windows 64-bit
- VST3 host (tested with Cubase 15; also hosts like Reaper, Bitwig, etc.)
- MSVC 14.44.35207, Windows SDK 10.0.26100.0, CMake 4.4.4 (for building)
- JUCE 9.0.4 at `C:/SDK/JUCE/install` (for building)

### Installation
1. Download the distribution ZIP for your platform
2. Extract to a location with write permissions (e.g., `C:/Program Files/Common Files/VST3/` or your VST3 scan folder)
3. In Cubase 15: Studio → Rescan VST Plug-ins, or let Cubase auto-discover
4. The VST3 bundle is `Project Seven.vst3`

### Controls
When the plugin opens:
- **Tuning**: Select a preset (Standard B, Drop A, Drop G, Drop F) or save/load custom tunings
- **String Set / Tuning**: Each string column shows the note, frequency, and damping slider; adjust per-string characteristics
- **Articulation**: Buttons for Open, Palm, Nat. Harm, Pinch; or use CC20
- **Plectrum & Pickup**: Pick position, pick force, pickup position controls
- **Voice**: Polyphony (max voices), bend range, output level

### MIDI Mapping
- C0 → Open articulation
- C#0 → Palm mute articulation
- D0 → Natural harmonic articulation
- D#0 → Pinch harmonic articulation
- CC20 → Articulation control
- CC64 → Sustain pedal (strings ring naturally after release)
- CC120/121/123 → All notes off variants

### Playing Tips
- **For djent palm mutes**: Use high velocity (0.8-1.0) with Palm Mute articulation. The strong pick attack creates the characteristic percussive chug. Adjust palm mute parameter for tighter/looser feel.
- **For sustain**: Let notes ring by releasing the key. The strings will continue to vibrate at their natural decay rate. Use sustain pedal (CC64) to hold notes longer.
- **For clean tones**: Use Open articulation with moderate velocity for clear, sustained notes.

## Documentation
- `BUILD.md` — how to build from source
- `ARCHITECTURE.md` — engine implementation details
- `TESTING.md` — test coverage and audio validation
- `CHANGELOG.md` — version history

## Current Status

This is a work-in-progress implementation. The following have been completed:
- Environment verified with all toolchain components
- Core engine/processor/editor implemented
- Enhanced physics engine with natural sustain and djenty palm mute
- Engine tests: 111 checks, 0 failures
- VST3 host smoke test passes
- Editor renders (visual verification completed)
- Static runtime confirmed (no MSVC runtime DLL dependencies)

## Known Limitations
- Cubase 15 / clean-machine validation not yet performed; only JUCE host smoke test and dependency inspection done
- Manual listening not yet performed; WAV artifacts available in release for manual testing
- Some edge cases may not be fully covered (e.g., simultaneous natural harmonics, extreme low tunings)

## License

Project Seven is released under the MIT License. See `LICENSE` for details.
