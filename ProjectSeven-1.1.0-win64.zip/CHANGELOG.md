# Changelog - Project Seven

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial implementation of physically modelled seven-string electric guitar VST3
- Extended Karplus-Strong / digital waveguide string synthesis
- Magnetic pickup sensing with position and harmonic cancellation
- Seven independent string configurations
- Tuning presets: Standard B, Drop A, Drop G, Drop F
- Custom tuning save/load (.ps7t XML format)
- MIDI support: note on/off, velocity, pitch bend, sustain, all-notes-off
- Keyswitches: C0 (Open), C#0 (Palm), D0 (Nat. Harm), D#0 (Pinch)
- CC20 articulation control, CC64 sustain
- Natural and pinch/artificial harmonics
- Palm muting with physical damping
- Clean DI output only (no built-in effects)
- Custom dark industrial editor GUI
- Editor snapshot tool for visual verification
- VST3 host smoke test
- Comprehensive engine test suite (111 checks)
- WAV artifacts for manual listening
- **Physics engine enhancements (v1.1)**:
  - Natural sustain: strings ring out after note release
  - Djenty palm mute: strong percussive attack with controlled decay
  - Improved loop filter: gentler damping for brighter, longer sustain
  - Realistic T60 decay times for electric guitar character
  - Sustain mode for extended ringing after note-off
  - Enhanced pick attack for palm-muted djent chugs

### Fixed
- Static MSVC runtime linking (no VCRUNTIME140/MSVCP140/UCRT dependencies)
- Zero audio-thread allocations during note-on/render
- Oversized host block processing with preallocated buffer
- Retrigger same note/string click prevention (6ms fade)
- Clicks/glitches stability at common sample rates and block sizes
- Note-off behavior: strings now ring naturally instead of stopping immediately
- Palm mute sound: improved djenty character with strong attack

### Known Issues
- Cubase 15 / clean-machine validation not performed (only JUCE host smoke test)
- Manual listening not performed (WAV artifacts available)
- Some edge cases may not be fully covered

## [1.1.0] - 2026-11-01

### Added
- Physics engine enhancements for realistic electric guitar behavior
- Natural sustain: strings continue vibrating after note release
- Djenty palm mute with strong percussive attack
- Improved loop filter for brighter, longer sustain
- Enhanced T60 decay times matching electric guitar characteristics
- Sustain mode for extended ringing
- Improved pick attack for palm-muted djent chugs

### Changed
- Updated loop filter cutoff frequencies (fc1Base 5200-10000 Hz, fc1Mute 1800 Hz)
- Extended T60 formula: 7.5 * pow(82.407/freq, 0.35) for base decay
- Increased transient level for palm mute (1.4x boost)
- Reduced palm mute threshold from 0.88 to 0.75 for less choked sound
- Extended note-off release times (0.15s palm mute, 0.3s open)
- Added sustain mode for natural string ring after release

### Fixed
- Note-off no longer kills string immediately; strings ring naturally
- Palm mute now produces djenty chug instead of weak sound
- All 111 tests pass with no regressions
- CPU improved to 0.72% real time (was 0.74%)

## [1.0.0] - 2026-10-31

### Added
- Initial public release
- All features as listed above
